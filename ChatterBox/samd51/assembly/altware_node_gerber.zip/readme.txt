Project Name: chatterbox_board_adafruit_v0.5
Project Version: #51dd0e9d
Project Url: https://www.flux.ai/mattcalhoun/chatterboxboardadafruitv0p5

Project Description:
Welcome to your new project. Imagine what you can build here.


